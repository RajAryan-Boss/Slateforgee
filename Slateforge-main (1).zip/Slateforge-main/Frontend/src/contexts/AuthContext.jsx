import React, { createContext, useState, useContext, useEffect } from 'react';

// Create auth context
const AuthContext = createContext();

// Custom hook for using auth
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Auth provider component
export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [user, setUser] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  
  // Check if user is logged in on initial load
  useEffect(() => {
    const checkAuth = () => {
      const savedAuth = localStorage.getItem('slateforge-auth');
      
      if (savedAuth) {
        try {
          const authData = JSON.parse(savedAuth);
          setIsAuthenticated(true);
          setUser(authData.user);
        } catch (error) {
          console.error('Error parsing auth data:', error);
          localStorage.removeItem('slateforge-auth');
        }
      }
      
      setIsLoading(false);
    };
    
    checkAuth();
  }, []);
  
  // Mock login function
  const login = (email, password) => {
    // In a real app, this would validate credentials with a backend
    const mockUser = {
      id: '1',
      name: 'John Doe',
      email: email,
      walletAddress: '0x71...3a9b'
    };
    
    setIsAuthenticated(true);
    setUser(mockUser);
    
    // Save auth state to localStorage
    localStorage.setItem(
      'slateforge-auth',
      JSON.stringify({ isAuthenticated: true, user: mockUser })
    );
    
    return true;
  };
  
  // Mock register function
  const register = (email, password) => {
    // In a real app, this would create a new user in the backend
    const mockUser = {
      id: '1',
      name: 'John Doe',
      email: email,
      walletAddress: '0x71...3a9b'
    };
    
    setIsAuthenticated(true);
    setUser(mockUser);
    
    // Save auth state to localStorage
    localStorage.setItem(
      'slateforge-auth',
      JSON.stringify({ isAuthenticated: true, user: mockUser })
    );
    
    return true;
  };
  
  // Logout function
  const logout = () => {
    setIsAuthenticated(false);
    setUser(null);
    localStorage.removeItem('slateforge-auth');
  };
  
  return (
    <AuthContext.Provider
      value={{
        isAuthenticated,
        user,
        isLoading,
        login,
        register,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContext;