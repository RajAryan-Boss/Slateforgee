import React, { createContext, useState, useEffect, useContext } from 'react';

// Create context
const WalletContext = createContext();

// Custom hook for using wallet context
export const useWallet = () => {
  const context = useContext(WalletContext);
  if (!context) {
    throw new Error('useWallet must be used within a WalletProvider');
  }
  return context;
};

export const WalletProvider = ({ children }) => {
  const [account, setAccount] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [chainId, setChainId] = useState('');
  const [error, setError] = useState('');

  // Check if MetaMask is installed
  const isMetaMaskInstalled = () => {
    return window.ethereum !== undefined;
  };

  // Handle account changes
  const handleAccountsChanged = (accounts) => {
    if (accounts.length === 0) {
      // MetaMask is locked or user has no accounts
      setAccount('');
      setIsConnected(false);
    } else {
      setAccount(accounts[0]);
      setIsConnected(true);
    }
  };

  // Handle chain changes
  const handleChainChanged = (newChainId) => {
    setChainId(newChainId);
  };

  // Connect to MetaMask
  const connectWallet = async () => {
    setError('');
    
    if (!isMetaMaskInstalled()) {
      setError('MetaMask is not installed. Please install MetaMask to connect.');
      return;
    }
    
    try {
      // Request account access
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      handleAccountsChanged(accounts);
      
      // Get current chain ID
      const chainId = await window.ethereum.request({ method: 'eth_chainId' });
      setChainId(chainId);
      
      return accounts[0];
    } catch (err) {
      if (err.code === 4001) {
        // User rejected the request
        setError('Please connect to MetaMask.');
      } else {
        setError('Failed to connect to MetaMask. Please try again.');
        console.error(err);
      }
    }
  };

  // Disconnect wallet (for UI purposes - actual disconnection handled by MetaMask)
  const disconnectWallet = () => {
    setAccount('');
    setIsConnected(false);
    setChainId('');
  };

  // Format address for display
  const formatAddress = (address) => {
    if (!address) return '';
    return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
  };

  // Set up event listeners for MetaMask
  useEffect(() => {
    if (isMetaMaskInstalled()) {
      // Check if already connected
      window.ethereum.request({ method: 'eth_accounts' })
        .then(handleAccountsChanged)
        .catch(err => console.error(err));
      
      // Set up listeners
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
      
      // Clean up listeners
      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, []);

  return (
    <WalletContext.Provider
      value={{
        account,
        isConnected,
        chainId,
        error,
        connectWallet,
        disconnectWallet,
        formatAddress
      }}
    >
      {children}
    </WalletContext.Provider>
  );
};

export default WalletContext;