import React, { createContext, useState, useContext, useEffect } from 'react';
import themes from '../utils/theme';

// Create theme context
const ThemeContext = createContext();

// Custom hook for using theme
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};

// Theme provider component
export const ThemeProvider = ({ children }) => {
  const [currentTheme, setCurrentTheme] = useState('dark');
  
  // Get the current theme object
  const theme = {
    ...themes[currentTheme],
    id: currentTheme
  };
  
  // Function to cycle through themes
  const cycleTheme = () => {
    if (currentTheme === 'dark') setCurrentTheme('cyberpunk');
    else if (currentTheme === 'cyberpunk') setCurrentTheme('light');
    else setCurrentTheme('dark');
  };
  
  // Function to set a specific theme
  const setTheme = (themeName) => {
    if (themes[themeName]) {
      setCurrentTheme(themeName);
    }
  };
  
  // Try to load saved theme from localStorage on initial load
  useEffect(() => {
    const savedTheme = localStorage.getItem('slateforge-theme');
    if (savedTheme && themes[savedTheme]) {
      setCurrentTheme(savedTheme);
    }
  }, []);
  
  // Save theme to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('slateforge-theme', currentTheme);
  }, [currentTheme]);
  
  return (
    <ThemeContext.Provider value={{ theme, currentTheme, cycleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeContext;