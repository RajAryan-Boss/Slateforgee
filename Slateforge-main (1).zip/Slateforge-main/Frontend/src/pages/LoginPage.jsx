import React from 'react';
import { Hexagon, Check } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import LoginForm from '../components/auth/LoginForm';
import ParticleAnimation from '../components/common/ParticleAnimation';

const LoginPage = ({ onSuccess, switchToRegister }) => {
  const { theme, currentTheme } = useTheme();

  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '1.5rem',
      position: 'relative',
    }}>
      <ParticleAnimation theme={theme} />
      
      {/* Background elements */}
      <div style={{
        position: 'absolute',
        top: '-20%',
        right: '-10%',
        width: '50%',
        height: '50%',
        borderRadius: '50%',
        background: theme.primary,
        opacity: 0.03,
        filter: 'blur(150px)',
        zIndex: 0,
      }}></div>
      <div style={{
        position: 'absolute',
        bottom: '-10%',
        left: '-5%',
        width: '40%',
        height: '40%',
        borderRadius: '50%',
        background: theme.secondary,
        opacity: 0.03,
        filter: 'blur(120px)',
        zIndex: 0,
      }}></div>
      
      <div style={{
        display: 'flex',
        maxWidth: '900px',
        width: '100%',
        borderRadius: '1rem',
        overflow: 'hidden',
        boxShadow: `0 25px 50px rgba(0, 0, 0, 0.15), 0 5px 20px ${theme.primary}20`,
        position: 'relative',
        zIndex: 1,
      }}>
        {/* Left panel */}
        <div style={{
          flex: '5',
          background: theme.background.card.primary,
          padding: '3rem',
          backdropFilter: 'blur(10px)',
          borderRight: `1px solid ${theme.border.primary}`,
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            marginBottom: '3rem',
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              background: theme.gradient.primary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 20px ${theme.primary}50`,
            }}>
              <Hexagon size={24} color={currentTheme === 'dark' ? '#0F172A' : 'white'} />
            </div>
            <span style={{
              fontSize: '1.5rem',
              fontWeight: 'bold',
              background: theme.gradient.primary,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              SlateForge
            </span>
          </div>
          
          <div style={{ marginBottom: '2rem' }}>
            <h2 style={{
              fontSize: '2rem',
              fontWeight: 'bold',
              marginBottom: '1rem',
            }}>
              Welcome back
            </h2>
            <p style={{
              color: theme.text.secondary,
            }}>
              Log in to access your decentralized asset management dashboard
            </p>
          </div>
          
          <LoginForm onSuccess={onSuccess} switchToRegister={switchToRegister} />
        </div>
        
        {/* Right panel */}
        <div style={{
          flex: '4',
          background: `linear-gradient(135deg, ${theme.background.secondary}, ${theme.background.tertiary})`,
          position: 'relative',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '2rem',
        }}>
          {/* Decorative elements */}
          <div style={{
            position: 'absolute',
            top: '10%',
            left: '10%',
            width: '80%',
            height: '80%',
            borderRadius: '30% 70% 70% 30% / 30% 30% 70% 70%',
            background: `linear-gradient(135deg, ${theme.primary}10, ${theme.secondary}10)`,
            animation: 'morphBlob 15s ease-in-out infinite alternate',
            opacity: 0.7,
          }}></div>
          
          <div style={{
            position: 'relative',
            zIndex: 1,
            textAlign: 'center',
            maxWidth: '80%',
          }}>
            <div style={{
              background: theme.gradient.secondary,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontSize: '1.25rem',
              fontWeight: 'bold',
              marginBottom: '1rem',
            }}>
              Decentralized Asset Management
            </div>
            <h3 style={{
              fontSize: '1.75rem',
              fontWeight: 'bold',
              marginBottom: '1.5rem',
            }}>
              Take control of your financial future
            </h3>
            <p style={{
              color: theme.text.secondary,
              marginBottom: '2rem',
              lineHeight: '1.6',
            }}>
              SlateForge empowers you with advanced tools to manage your crypto assets across multiple blockchains with ease and security.
            </p>
            
            <div style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '1rem',
              marginBottom: '2rem',
              justifyContent: 'center',
            }}>
              <div style={{
                padding: '0.75rem 1rem',
                background: theme.background.card.secondary,
                borderRadius: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                backdropFilter: 'blur(10px)',
              }}>
                <Check size={16} color={theme.success} />
                <span style={{ fontSize: '0.9rem' }}>Multi-chain support</span>
              </div>
              <div style={{
                padding: '0.75rem 1rem',
                background: theme.background.card.secondary,
                borderRadius: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                backdropFilter: 'blur(10px)',
              }}>
                <Check size={16} color={theme.success} />
                <span style={{ fontSize: '0.9rem' }}>AI-powered strategies</span>
              </div>
              <div style={{
                padding: '0.75rem 1rem',
                background: theme.background.card.secondary,
                borderRadius: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                backdropFilter: 'blur(10px)',
              }}>
                <Check size={16} color={theme.success} />
                <span style={{ fontSize: '0.9rem' }}>Advanced security</span>
              </div>
              <div style={{
                padding: '0.75rem 1rem',
                background: theme.background.card.secondary,
                borderRadius: '0.5rem',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                backdropFilter: 'blur(10px)',
              }}>
                <Check size={16} color={theme.success} />
                <span style={{ fontSize: '0.9rem' }}>Real-time analytics</span>
              </div>
            </div>
          </div>
          
          <style jsx>{`
            @keyframes morphBlob {
              0% {
                border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
              }
              25% {
                border-radius: 58% 42% 75% 25% / 76% 46% 54% 24%;
              }
              50% {
                border-radius: 50% 50% 33% 67% / 55% 27% 73% 45%;
              }
              75% {
                border-radius: 33% 67% 58% 42% / 63% 68% 32% 37%;
              }
              100% {
                border-radius: 30% 70% 70% 30% / 30% 30% 70% 70%;
              }
            }
          `}</style>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;