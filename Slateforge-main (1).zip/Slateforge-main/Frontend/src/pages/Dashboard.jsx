import React from 'react';
import DashboardLayout from '../layouts/DashboardLayout';
import PerformanceMetrics from '../components/dashboard/PerformanceMetrics';
import PortfolioChart from '../components/dashboard/PortfolioChart';
import AssetAllocation from '../components/dashboard/AssetAllocation';
import RecentTransactions from '../components/dashboard/RecentTransactions';
import CrossChainBridge from '../components/dashboard/CrossChainBridge';
import ActiveStrategies from '../components/dashboard/ActiveStrategies';
import { useTheme } from '../contexts/ThemeContext';

const Dashboard = () => {
  const { theme, currentTheme } = useTheme();

  // Section header component with visible text in all themes
  const SectionHeader = ({ title, icon, primary = true }) => {
    // Get text color based on theme and primary flag
    const getTextColor = () => {
      if (currentTheme === 'dark') {
        return primary ? theme.primary : theme.secondary;
      } else if (currentTheme === 'cyberpunk') {
        return primary ? '#FF2A6D' : '#05D9E8'; // Neon theme colors
      } else {
        return primary ? '#0EA5E9' : '#8B5CF6'; // Light theme colors
      }
    };

    return (
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: '0.75rem',
        marginBottom: '1rem',
        padding: '0.75rem 1rem',
        borderRadius: '0.5rem',
        background: 'rgba(0, 0, 0, 0.05)',
        backdropFilter: 'blur(4px)',
      }}>
        {icon}
        <h3 style={{
          fontSize: '1.1rem',
          fontWeight: 'bold',
          color: getTextColor(),
          margin: 0,
        }}>
          {title}
        </h3>
      </div>
    );
  };

  return (
    <DashboardLayout title="Dashboard">
      {/* Performance metrics */}
      <PerformanceMetrics />
      
      {/* Charts section */}
      <SectionHeader 
        title="Portfolio Analytics" 
        icon={<div style={{
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          background: currentTheme === 'cyberpunk' ? '#FF2A6D' : 
                     currentTheme === 'light' ? '#0EA5E9' : theme.primary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          fontSize: '0.75rem',
        }}></div>} 
      />
      
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(500px, 1fr))',
        gap: '1.5rem',
        marginBottom: '1.5rem',
      }}>
        <PortfolioChart />
        <AssetAllocation />
      </div>
      
      {/* Active Strategies */}
      <SectionHeader 
        title="Investment Strategies" 
        icon={<div style={{
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          background: currentTheme === 'cyberpunk' ? '#05D9E8' : 
                     currentTheme === 'light' ? '#8B5CF6' : theme.secondary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          fontSize: '0.75rem',
        }}></div>}
        primary={false}
      />
      
      <ActiveStrategies />
      
      {/* Recent transactions */}
      <SectionHeader 
        title="Transaction History" 
        icon={<div style={{
          width: '24px',
          height: '24px',
          borderRadius: '50%',
          background: currentTheme === 'cyberpunk' ? '#FF2A6D' : 
                     currentTheme === 'light' ? '#0EA5E9' : theme.primary,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: 'white',
          fontSize: '0.75rem',
        }}></div>}
      />
      
      <RecentTransactions />
      
      {/* Cross-chain bridge */}
      <div style={{ marginTop: '1.5rem', marginBottom: '1.5rem' }}>
        <SectionHeader 
          title="Cross-Chain Transfer" 
          icon={<div style={{
            width: '24px',
            height: '24px',
            borderRadius: '50%',
            background: currentTheme === 'cyberpunk' ? '#05D9E8' : 
                       currentTheme === 'light' ? '#8B5CF6' : theme.accent,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            color: 'white',
            fontSize: '0.75rem',
          }}></div>}
          primary={false}
        />
        
        <CrossChainBridge />
      </div>
    </DashboardLayout>
  );
};

export default Dashboard;