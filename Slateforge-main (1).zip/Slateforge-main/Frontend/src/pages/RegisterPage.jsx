import React from 'react';
import { Hexagon, ChartPie, Shield, Layers } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import RegisterForm from '../components/auth/RegisterForm';
import ParticleAnimation from '../components/common/ParticleAnimation';

const RegisterPage = ({ onSuccess, switchToLogin }) => {
  const { theme, currentTheme } = useTheme();

  return (
    <div style={{ 
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: '1.5rem',
      position: 'relative',
    }}>
      <ParticleAnimation theme={theme} />
      
      {/* Background elements */}
      <div style={{
        position: 'absolute',
        top: '-20%',
        right: '-10%',
        width: '50%',
        height: '50%',
        borderRadius: '50%',
        background: theme.secondary,
        opacity: 0.03,
        filter: 'blur(150px)',
        zIndex: 0,
      }}></div>
      <div style={{
        position: 'absolute',
        bottom: '-10%',
        left: '-5%',
        width: '40%',
        height: '40%',
        borderRadius: '50%',
        background: theme.primary,
        opacity: 0.03,
        filter: 'blur(120px)',
        zIndex: 0,
      }}></div>
      
      <div style={{
        display: 'flex',
        maxWidth: '900px',
        width: '100%',
        borderRadius: '1rem',
        overflow: 'hidden',
        boxShadow: `0 25px 50px rgba(0, 0, 0, 0.15), 0 5px 20px ${theme.primary}20`,
        position: 'relative',
        zIndex: 1,
      }}>
        {/* Left panel for register form */}
        <div style={{
          flex: '5',
          background: theme.background.card.primary,
          padding: '3rem',
          backdropFilter: 'blur(10px)',
          borderRight: `1px solid ${theme.border.primary}`,
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            marginBottom: '3rem',
          }}>
            <div style={{
              width: '40px',
              height: '40px',
              borderRadius: '10px',
              background: theme.gradient.secondary,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              boxShadow: `0 0 20px ${theme.secondary}50`,
            }}>
              <Hexagon size={24} color={currentTheme === 'dark' ? '#0F172A' : 'white'} />
            </div>
            <span style={{
              fontSize: '1.5rem',
              fontWeight: 'bold',
              background: theme.gradient.secondary,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
            }}>
              SlateForge
            </span>
          </div>
          
          <div style={{ marginBottom: '2rem' }}>
            <h2 style={{
              fontSize: '2rem',
              fontWeight: 'bold',
              marginBottom: '1rem',
            }}>
              Create your account
            </h2>
            <p style={{
              color: theme.text.secondary,
            }}>
              Join thousands of investors using SlateForge for decentralized asset management
            </p>
          </div>
          
          <RegisterForm onSuccess={onSuccess} switchToLogin={switchToLogin} />
        </div>
        
        {/* Right panel for benefits */}
        <div style={{
          flex: '4',
          background: `linear-gradient(135deg, ${theme.background.secondary}, ${theme.background.tertiary})`,
          position: 'relative',
          overflow: 'hidden',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '2rem',
        }}>
          {/* Decorative elements */}
          <div style={{
            position: 'absolute',
            top: '10%',
            left: '10%',
            width: '80%',
            height: '80%',
            borderRadius: '70% 30% 30% 70% / 60% 40% 60% 40%',
            background: `linear-gradient(135deg, ${theme.secondary}10, ${theme.primary}10)`,
            animation: 'morphBlob2 15s ease-in-out infinite alternate',
            opacity: 0.7,
          }}></div>
          
          <div style={{
            position: 'relative',
            zIndex: 1,
            textAlign: 'center',
            maxWidth: '80%',
          }}>
            <div style={{
              background: theme.gradient.accent,
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              fontSize: '1.25rem',
              fontWeight: 'bold',
              marginBottom: '1rem',
            }}>
              Join the Financial Revolution
            </div>
            <h3 style={{
              fontSize: '1.75rem',
              fontWeight: 'bold',
              marginBottom: '1.5rem',
            }}>
              Benefits of SlateForge
            </h3>
            
            <div style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '1.25rem',
              marginBottom: '2rem',
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '1rem',
                textAlign: 'left',
              }}>
                <div style={{
                  padding: '0.75rem',
                  borderRadius: '0.75rem',
                  background: `${theme.primary}15`,
                  color: theme.primary,
                }}>
                  <ChartPie size={24} />
                </div>
                <div>
                  <h4 style={{
                    fontWeight: 'bold',
                    marginBottom: '0.5rem',
                  }}>Portfolio Optimization</h4>
                  <p style={{
                    color: theme.text.secondary,
                    fontSize: '0.9rem',
                    lineHeight: '1.5',
                  }}>
                    AI-powered strategies to maximize returns based on your risk profile
                  </p>
                </div>
              </div>
              
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '1rem',
                textAlign: 'left',
              }}>
                <div style={{
                  padding: '0.75rem',
                  borderRadius: '0.75rem',
                  background: `${theme.secondary}15`,
                  color: theme.secondary,
                }}>
                  <Shield size={24} />
                </div>
                <div>
                  <h4 style={{
                    fontWeight: 'bold',
                    marginBottom: '0.5rem',
                  }}>Enhanced Security</h4>
                  <p style={{
                    color: theme.text.secondary,
                    fontSize: '0.9rem',
                    lineHeight: '1.5',
                  }}>
                    Non-custodial solutions with advanced encryption and secure smart contracts
                  </p>
                </div>
              </div>
              
              <div style={{
                display: 'flex',
                alignItems: 'flex-start',
                gap: '1rem',
                textAlign: 'left',
              }}>
                <div style={{
                  padding: '0.75rem',
                  borderRadius: '0.75rem',
                  background: `${theme.accent}15`,
                  color: theme.accent,
                }}>
                  <Layers size={24} />
                </div>
                <div>
                  <h4 style={{
                    fontWeight: 'bold',
                    marginBottom: '0.5rem',
                  }}>Cross-Chain Freedom</h4>
                  <p style={{
                    color: theme.text.secondary,
                    fontSize: '0.9rem',
                    lineHeight: '1.5',
                  }}>
                    Seamlessly manage assets across multiple blockchains with low-fee bridges
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          <style jsx>{`
            @keyframes morphBlob2 {
              0% {
                border-radius: 70% 30% 30% 70% / 60% 40% 60% 40%;
              }
              25% {
                border-radius: 40% 60% 54% 46% / 49% 60% 40% 51%;
              }
              50% {
                border-radius: 50% 50% 33% 67% / 55% 27% 73% 45%;
              }
              75% {
                border-radius: 42% 58% 30% 70% / 45% 45% 55% 55%;
              }
              100% {
                border-radius: 70% 30% 30% 70% / 60% 40% 60% 40%;
              }
            }
          `}</style>
        </div>
      </div>
    </div>
  );
};

export default RegisterPage;