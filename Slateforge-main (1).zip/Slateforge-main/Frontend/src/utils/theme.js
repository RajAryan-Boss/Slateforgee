// Theme configuration for SlateForge
const themes = {
    dark: {
      primary: '#10B981', // Emerald green
      secondary: '#6366F1', // Indigo
      accent: '#14B8A6', // Teal
      success: '#10B981', // Green
      warning: '#F59E0B', // Amber
      danger: '#EF4444', // Red
      background: {
        primary: '#0F172A', // Very dark blue
        secondary: '#1E293B', // Dark blue/gray
        tertiary: '#334155', // Medium blue/gray
        card: {
          primary: 'rgba(30, 41, 59, 0.8)', // Semi-transparent dark card
          secondary: 'rgba(51, 65, 85, 0.8)', // Lighter semi-transparent card
          highlight: 'rgba(16, 185, 129, 0.08)' // Subtle emerald highlight
        }
      },
      text: {
        primary: '#F9FAFB', // White
        secondary: '#E5E7EB', // Light gray
        tertiary: '#9CA3AF', // Medium gray
      },
      border: {
        primary: '#334155', // Medium blue/gray
        highlight: '#10B98160' // Semi-transparent accent
      },
      gradient: {
        primary: 'linear-gradient(135deg, #10B981 0%, #14B8A6 100%)',
        secondary: 'linear-gradient(135deg, #14B8A6 0%, #6366F1 100%)',
        accent: 'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
      }
    },
    cyberpunk: {
      primary: '#FF2A6D', // Neon pink
      secondary: '#05D9E8', // Neon blue
      accent: '#D1F7FF', // Light blue
      success: '#01FFC3', // Neon green
      warning: '#FFBD01', // Neon yellow
      danger: '#FF2A6D', // Neon pink
      background: {
        primary: '#0F0E17', // Very dark blue/black
        secondary: '#1A1A2E', // Dark blue
        tertiary: '#16213E', // Medium dark blue
        card: {
          primary: 'rgba(26, 26, 46, 0.8)', // Semi-transparent dark card
          secondary: 'rgba(22, 33, 62, 0.8)', // Lighter semi-transparent card
          highlight: 'rgba(255, 42, 109, 0.08)' // Subtle neon highlight
        }
      },
      text: {
        primary: '#FFFFFF', // White
        secondary: '#D1D1E9', // Light lavender
        tertiary: '#A7A7C6', // Medium lavender
      },
      border: {
        primary: '#2B2B45', // Medium blue
        highlight: '#FF2A6D60' // Semi-transparent accent
      },
      gradient: {
        primary: 'linear-gradient(135deg, #FF2A6D 0%, #FF9190 100%)', 
        secondary: 'linear-gradient(135deg, #05D9E8 0%, #01FFC3 100%)',
        accent: 'linear-gradient(135deg, #7678ED 0%, #F7B801 100%)',
      }
    },
    light: {
      primary: '#0EA5E9', // Sky blue
      secondary: '#8B5CF6', // Purple
      accent: '#06B6D4', // Cyan
      success: '#10B981', // Green
      warning: '#F59E0B', // Amber
      danger: '#EF4444', // Red
      background: {
        primary: '#F1F5F9', // Light gray/blue
        secondary: '#E2E8F0', // Light gray
        tertiary: '#CBD5E1', // Medium light gray
        card: {
          primary: 'rgba(255, 255, 255, 0.8)', // Semi-transparent white card
          secondary: 'rgba(226, 232, 240, 0.8)', // Lighter semi-transparent card
          highlight: 'rgba(14, 165, 233, 0.08)' // Subtle blue highlight
        }
      },
      text: {
        primary: '#0F172A', // Very dark blue
        secondary: '#1E293B', // Dark blue/gray
        tertiary: '#64748B', // Medium gray/blue
      },
      border: {
        primary: '#CBD5E1', // Medium light gray
        highlight: '#0EA5E960' // Semi-transparent accent
      },
      gradient: {
        primary: 'linear-gradient(135deg, #0EA5E9 0%, #06B6D4 100%)',
        secondary: 'linear-gradient(135deg, #06B6D4 0%, #8B5CF6 100%)',
        accent: 'linear-gradient(135deg, #8B5CF6 0%, #EC4899 100%)',
      }
    }
  };
  
  export default themes;