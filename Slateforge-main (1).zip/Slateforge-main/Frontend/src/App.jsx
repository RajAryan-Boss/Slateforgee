import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { WalletProvider } from './contexts/WalletContext';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import Dashboard from './pages/Dashboard';

// Main App wrapper with providers
const AppWithProviders = () => {
  return (
    <ThemeProvider>
      <AuthProvider>
        <WalletProvider>
          <AppContent />
        </WalletProvider>
      </AuthProvider>
    </ThemeProvider>
  );
};

// App content that uses the providers
const AppContent = () => {
  const { isAuthenticated, isLoading } = useAuth();
  const [currentPage, setCurrentPage] = useState('login');
  
  if (isLoading) {
    // Show loading state
    return (
      <div style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: '1.25rem',
      }}>
        Loading...
      </div>
    );
  }
  
  // If authenticated, show the dashboard
  if (isAuthenticated) {
    return <Dashboard />;
  }
  
  // Otherwise, show login or register page
  return (
    <>
      {currentPage === 'login' ? (
        <LoginPage
          onSuccess={() => {}}
          switchToRegister={() => setCurrentPage('register')}
        />
      ) : (
        <RegisterPage
          onSuccess={() => {}}
          switchToLogin={() => setCurrentPage('login')}
        />
      )}
    </>
  );
};

export default AppWithProviders;