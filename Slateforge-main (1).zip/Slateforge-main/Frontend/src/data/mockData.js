// Sample portfolio data
export const portfolioData = [
    { name: 'Jan', value: 4000 },
    { name: 'Feb', value: 3000 },
    { name: 'Mar', value: 5000 },
    { name: 'Apr', value: 2780 },
    { name: 'May', value: 1890 },
    { name: 'Jun', value: 2390 },
    { name: 'Jul', value: 3490 },
    { name: 'Aug', value: 4000 },
    { name: 'Sep', value: 4500 },
    { name: 'Oct', value: 5200 },
    { name: 'Nov', value: 6000 },
    { name: 'Dec', value: 7000 },
  ];
  
  // Sample asset allocation data
  export const assetAllocation = [
    { name: 'ETH', value: 35, color: '#627EEA' },
    { name: 'BTC', value: 25, color: '#F7931A' },
    { name: 'SOL', value: 15, color: '#00FFA3' },
    { name: 'USDC', value: 10, color: '#2775CA' },
    { name: 'Other', value: 15, color: '#14B8A6' },
  ];
  
  // Sample transaction history
  export const recentTransactions = [
    { id: 1, type: 'Buy', asset: 'ETH', amount: '0.45', value: '$1,245.00', time: '2 hours ago', status: 'Completed', change: 'up', chainIcon: '🔷' },
    { id: 2, type: 'Sell', asset: 'SOL', amount: '12.3', value: '$985.20', time: '5 hours ago', status: 'Completed', change: 'down', chainIcon: '☀️' },
    { id: 3, type: 'Swap', asset: 'USDC → BTC', amount: '500', value: '$500.00', time: '1 day ago', status: 'Completed', change: 'up', chainIcon: '🔶' },
    { id: 4, type: 'Stake', asset: 'ETH', amount: '1.2', value: '$3,300.00', time: '2 days ago', status: 'Pending', change: 'neutral', chainIcon: '🔷' },
  ];
  
  // Sample performance metrics
  export const performanceMetrics = [
    { metric: 'Portfolio Value', value: '$84,245.26', change: '+12.4%', trend: 'up' },
    { metric: '24h Change', value: '$1,245.67', change: '+2.8%', trend: 'up' },
    { metric: '7d Performance', value: '$3,567.89', change: '+5.6%', trend: 'up' },
    { metric: 'Active Strategies', value: '5', change: '+2', trend: 'up' },
  ];
  
  // Sample strategies
  export const activeStrategies = [
    { id: 1, name: 'DCA - ETH', status: 'Active', description: 'Dollar-cost averaging into ETH weekly', allocation: '$500/week', returns: '+15.4%', riskLevel: 'Medium' },
    { id: 2, name: 'Yield Farming AAVE', status: 'Active', description: 'Lending assets on AAVE for yield', allocation: '$10,000', returns: '+8.2%', riskLevel: 'Low' },
    { id: 3, name: 'BTC-ETH Rebalance', status: 'Active', description: '60/40 weighted portfolio with monthly rebalancing', allocation: '$25,000', returns: '+12.7%', riskLevel: 'Medium' },
    { id: 4, name: 'Polygon Staking', status: 'Paused', description: 'Staking MATIC for passive income', allocation: '$5,000', returns: '+18.3%', riskLevel: 'Medium-High' },
  ];
  
  // Sample recommended strategies
  export const recommendedStrategies = [
    { id: 1, name: 'Blue Chip DeFi', description: 'Diversified allocation to established DeFi protocols', expectedReturn: '11-15%', riskLevel: 'Medium', chains: ['Ethereum', 'Solana'] },
    { id: 2, name: 'Stablecoin Yield', description: 'Generate safe yield from stablecoin lending and LPs', expectedReturn: '6-8%', riskLevel: 'Low', chains: ['Ethereum', 'BSC', 'Avalanche'] },
    { id: 3, name: 'Layer 2 Growth', description: 'Strategic positions in growing L2 ecosystems', expectedReturn: '15-22%', riskLevel: 'High', chains: ['Arbitrum', 'Optimism', 'zkSync'] },
  ];
  
  // Sample connected chains
  export const connectedChains = [
    { id: 'ethereum', name: 'Ethereum', color: '#627EEA', assets: 5, totalValue: '$45,230.05', icon: '🔷' },
    { id: 'polygon', name: 'Polygon', color: '#8247E5', assets: 3, totalValue: '$12,450.30', icon: '🟣' },
    { id: 'solana', name: 'Solana', color: '#00FFA3', assets: 2, totalValue: '$8,750.90', icon: '☀️' },
    { id: 'binance', name: 'BNB Chain', color: '#F0B90B', assets: 1, totalValue: '$2,355.45', icon: '🟡' },
  ];
  
  // Sample news and updates
  export const newsUpdates = [
    { id: 1, title: 'SlateForge integrates with zkSync Era', date: '2 days ago', category: 'Integration', link: '#' },
    { id: 2, title: 'New AI-powered strategy recommendations launched', date: '5 days ago', category: 'Feature', link: '#' },
    { id: 3, title: 'SlateForge surpasses $100M in TVL', date: '1 week ago', category: 'Milestone', link: '#' },
  ];