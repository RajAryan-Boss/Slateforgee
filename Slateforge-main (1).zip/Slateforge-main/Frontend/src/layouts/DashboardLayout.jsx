import React, { useState, useEffect } from 'react';
import { Bell, Wallet, AlertCircle } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import { useAuth } from '../contexts/AuthContext';
import { useWallet } from '../contexts/WalletContext';
import Sidebar from '../components/common/Sidebar';
import ParticleAnimation from '../components/common/ParticleAnimation';

const DashboardLayout = ({ children, title }) => {
  const { theme, currentTheme } = useTheme();
  const { user } = useAuth();
  const { isConnected, account, connectWallet, formatAddress, error } = useWallet();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
  const [showError, setShowError] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Handle responsive behavior
  useEffect(() => {
    const handleResize = () => {
      setIsMobile(window.innerWidth <= 768);
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Display error message when wallet connection fails
  useEffect(() => {
    if (error) {
      setShowError(true);
      const timer = setTimeout(() => {
        setShowError(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [error]);

  // Get correct text style based on theme
  const getTitleStyle = () => {
    const baseStyle = {
      fontSize: isMobile ? '1.25rem' : '1.5rem', 
      fontWeight: 'bold',
    };
    
    // Use direct color for Neon and Light themes, gradient for Dark Emerald
    if (currentTheme === 'dark') {
      return {
        ...baseStyle,
        background: theme.gradient.primary,
        WebkitBackgroundClip: 'text',
        WebkitTextFillColor: 'transparent',
      };
    } else if (currentTheme === 'cyberpunk') {
      return {
        ...baseStyle,
        color: '#FF2A6D', // Neon theme primary color
      };
    } else {
      return {
        ...baseStyle,
        color: '#0EA5E9', // Light theme primary color
      };
    }
  };

  return (
    <div style={{
      display: 'flex',
      height: '100vh',
      position: 'relative',
      zIndex: 1,
    }}>
      {/* Sidebar */}
      <Sidebar 
        currentPage={currentPage} 
        setCurrentPage={setCurrentPage} 
        walletAddress={isConnected ? formatAddress(account) : null}
        onSidebarToggle={(collapsed) => setSidebarCollapsed(collapsed)}
      />
      
      {/* Main content */}
      <div style={{
        flex: 1,
        height: '100vh',
        overflow: 'auto',
        position: 'relative',
        background: theme.background.primary,
      }}>
        {/* Background effects */}
        <div style={{
          position: 'absolute',
          top: '-10%',
          right: '-10%',
          width: '40%',
          height: '40%',
          borderRadius: '50%',
          background: theme.primary,
          opacity: 0.05,
          filter: 'blur(60px)',
          zIndex: 0,
        }}></div>
        <div style={{
          position: 'absolute',
          bottom: '-10%',
          left: '-5%',
          width: '30%',
          height: '30%',
          borderRadius: '50%',
          background: theme.secondary,
          opacity: 0.05,
          filter: 'blur(60px)',
          zIndex: 0,
        }}></div>
        
        {/* Hexagon grid pattern in background */}
        <div style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          opacity: 0.05,
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cpath d='M30 0l30 17.5v35l-30 17.5-30-17.5v-35l30-17.5z' fill='none' stroke='%23${theme.primary.substring(1)}' stroke-width='1'/%3E%3C/svg%3E")`,
          backgroundSize: '60px 60px',
          zIndex: 0,
        }}></div>
        
        {/* Particle Animation */}
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, zIndex: 0, opacity: 0.5 }}>
          <ParticleAnimation theme={theme} />
        </div>
        
        {/* Header */}
        <header style={{
          padding: '1rem 1.5rem',
          borderBottom: `1px solid ${theme.border.primary}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          position: 'sticky',
          top: 0,
          background: `${theme.background.primary}CC`,
          backdropFilter: 'blur(10px)',
          zIndex: 10,
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
            marginLeft: sidebarCollapsed ? '3rem' : '0',
          }}>
            <h1 style={getTitleStyle()}>{title}</h1>
            <div style={{
              padding: '0.25rem 0.5rem',
              borderRadius: '0.25rem',
              fontSize: '0.75rem',
              background: 'rgba(0, 0, 0, 0.1)',
              color: theme.text.tertiary,
              display: isMobile ? 'none' : 'block',
            }}>
              Last updated: 2 min ago
            </div>
          </div>
          
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '1rem',
          }}>
            <div style={{
              position: 'relative',
              cursor: 'pointer',
            }}>
              <Bell size={20} />
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '8px',
                height: '8px',
                borderRadius: '50%',
                background: theme.danger,
              }}></div>
            </div>
            
            <button
              onClick={connectWallet}
              style={{
                padding: isMobile ? '0.5rem' : '0.5rem 1rem',
                borderRadius: '0.5rem',
                background: theme.gradient.primary,
                color: currentTheme === 'dark' ? '#0F172A' : 'white',
                fontWeight: 'medium',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                boxShadow: `0 0 10px ${theme.primary}40`,
                border: 'none',
              }}
            >
              <Wallet size={16} />
              {!isMobile && (
                <span>{isConnected ? formatAddress(account) : 'Connect Wallet'}</span>
              )}
            </button>
          </div>
        </header>
        
        {/* Wallet connection error message */}
        {showError && (
          <div style={{
            position: 'fixed',
            top: '5rem',
            right: '1.5rem',
            padding: '0.75rem 1rem',
            background: `${theme.danger}20`,
            border: `1px solid ${theme.danger}`,
            borderRadius: '0.5rem',
            color: theme.danger,
            zIndex: 100,
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
            maxWidth: '300px',
            backdropFilter: 'blur(4px)',
          }}>
            <AlertCircle size={16} />
            <span>{error}</span>
          </div>
        )}
        
        {/* Content */}
        <main style={{ 
          padding: isMobile ? '1rem' : '1.5rem', 
          position: 'relative', 
          zIndex: 1,
        }}>
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;