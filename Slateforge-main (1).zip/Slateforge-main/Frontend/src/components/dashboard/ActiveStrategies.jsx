import React from 'react';
import { ArrowUpRight, Play, Pause, Zap } from 'lucide-react';
import FloatingCard from '../common/FloatingCard';
import { useTheme } from '../../contexts/ThemeContext';
import { activeStrategies } from '../../data/mockData';

const ActiveStrategies = () => {
  const { theme, currentTheme } = useTheme();

  // Function to get text color based on theme
  const getTitleColor = () => {
    if (currentTheme === 'cyberpunk') {
      return '#05D9E8'; // Neon blue for cyberpunk theme
    } else if (currentTheme === 'light') {
      return '#8B5CF6'; // Purple for light theme
    } else {
      return '#6366F1'; // Indigo for dark theme
    }
  };

  // Function to get title style for "Active Strategies"
  const getTitleStyle = () => {
    return {
      fontSize: '1.1rem',
      fontWeight: 'bold',
      color: getTitleColor(),
      padding: '0.5rem 1rem',
      backgroundColor: 'rgba(0, 0, 0, 0.15)',
      borderRadius: '0.25rem',
      marginBottom: '1rem',
      display: 'inline-block'
    };
  };

  return (
    <div style={{ marginBottom: '1.5rem' }}>
      {/* Title bar for "Active Strategies" */}
      <div style={getTitleStyle()}>
        Active Strategies
      </div>
      
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
        gap: '1rem',
      }}>
        {activeStrategies.map((strategy, index) => (
          <FloatingCard key={index} theme={theme} intensity={0.4}>
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'flex-start',
              marginBottom: '1rem',
            }}>
              <div style={{
                display: 'flex',
                flexDirection: 'column',
              }}>
                <h4 style={{ fontWeight: 'bold', marginBottom: '0.25rem' }}>{strategy.name}</h4>
                <p style={{ fontSize: '0.875rem', color: theme.text.tertiary }}>{strategy.description}</p>
              </div>
              
              <div style={{
                padding: '0.25rem 0.5rem',
                borderRadius: '1rem',
                background: strategy.status === 'Active' ? `${theme.success}20` : `${theme.warning}20`,
                color: strategy.status === 'Active' ? theme.success : theme.warning,
                fontSize: '0.75rem',
              }}>
                {strategy.status}
              </div>
            </div>
            
            <div style={{
              display: 'flex',
              justifyContent: 'space-between',
              marginBottom: '1rem',
            }}>
              <div>
                <div style={{ fontSize: '0.75rem', color: theme.text.tertiary, marginBottom: '0.25rem' }}>Allocation</div>
                <div style={{ fontWeight: 'medium' }}>{strategy.allocation}</div>
              </div>
              
              <div>
                <div style={{ fontSize: '0.75rem', color: theme.text.tertiary, marginBottom: '0.25rem' }}>Returns</div>
                <div style={{ 
                  fontWeight: 'medium',
                  color: theme.success,
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.25rem',
                }}>
                  <ArrowUpRight size={14} />
                  {strategy.returns}
                </div>
              </div>
              
              <div>
                <div style={{ fontSize: '0.75rem', color: theme.text.tertiary, marginBottom: '0.25rem' }}>Risk</div>
                <div style={{ fontWeight: 'medium' }}>{strategy.riskLevel}</div>
              </div>
            </div>
            
            <div style={{
              display: 'flex',
              gap: '0.5rem',
            }}>
              <button style={{
                flex: 1,
                padding: '0.5rem',
                background: theme.gradient.secondary,
                border: 'none',
                borderRadius: '0.5rem',
                color: 'white',
                fontSize: '0.875rem',
                fontWeight: 'medium',
                cursor: 'pointer',
              }}>
                Manage
              </button>
              
              <button style={{
                width: '38px',
                padding: '0.5rem',
                background: theme.background.tertiary,
                border: 'none',
                borderRadius: '0.5rem',
                color: theme.text.secondary,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                cursor: 'pointer',
              }}>
                {strategy.status === 'Active' ? <Pause size={16} /> : <Play size={16} />}
              </button>
            </div>
          </FloatingCard>
        ))}
      </div>
    </div>
  );
};

export default ActiveStrategies;