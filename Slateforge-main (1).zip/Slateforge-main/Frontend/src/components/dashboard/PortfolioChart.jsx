import React, { useState } from 'react';
import { LineChart, Line, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import FloatingCard from '../common/FloatingCard';
import { useTheme } from '../../contexts/ThemeContext';
import { portfolioData } from '../../data/mockData';

const PortfolioChart = () => {
  const { theme, currentTheme } = useTheme();
  const [timeframe, setTimeframe] = useState('1M');
  
  const timeframes = ['1D', '1W', '1M', '1Y', 'All'];
  
  // Function to get text color based on theme
  const getChartTitleColor = () => {
    if (currentTheme === 'cyberpunk') {
      return '#FF2A6D'; // Neon pink for cyberpunk theme
    } else if (currentTheme === 'light') {
      return '#0EA5E9'; // Blue for light theme
    } else {
      return '#10B981'; // Green for dark theme
    }
  };
  
  // Add title text directly in the component instead of using a separate bar
  return (
    <FloatingCard theme={theme} intensity={0.3}>
      {/* Title showing "Portfolio Performance" text directly */}
      <div style={{
        fontSize: '1.1rem',
        fontWeight: 'bold',
        marginBottom: '1rem',
        color: getChartTitleColor()
      }}>
        Portfolio Performance
      </div>
      
      <div style={{
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'center',
        marginBottom: '1rem',
      }}>
        <div style={{
          display: 'flex',
          gap: '0.5rem',
        }}>
          {timeframes.map((tf) => (
            <button 
              key={tf}
              onClick={() => setTimeframe(tf)}
              style={{
                padding: '0.25rem 0.75rem',
                borderRadius: '0.25rem',
                fontSize: '0.875rem',
                fontWeight: 'medium',
                background: timeframe === tf ? theme.gradient.primary : theme.background.tertiary,
                color: timeframe === tf 
                  ? (currentTheme === 'dark' ? '#0F172A' : 'white') 
                  : theme.text.secondary,
                border: 'none',
                cursor: 'pointer',
              }}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>
      
      <div style={{ height: '300px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={portfolioData}>
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor={theme.primary} stopOpacity={0.8}/>
                <stop offset="95%" stopColor={theme.primary} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <XAxis 
              dataKey="name" 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: theme.text.tertiary }} 
            />
            <YAxis 
              axisLine={false} 
              tickLine={false} 
              tick={{ fill: theme.text.tertiary }} 
            />
            <CartesianGrid 
              stroke={theme.border.primary} 
              strokeDasharray="3 3" 
              vertical={false} 
            />
            <Tooltip 
              contentStyle={{ 
                background: theme.background.card.primary,
                border: `1px solid ${theme.border.primary}`,
                borderRadius: '0.5rem',
              }} 
            />
            <Area 
              type="monotone" 
              dataKey="value" 
              stroke={theme.primary} 
              strokeWidth={2}
              fillOpacity={1} 
              fill="url(#colorValue)" 
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </FloatingCard>
  );
};

export default PortfolioChart;