import React from 'react';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import FloatingCard from '../common/FloatingCard';
import { useTheme } from '../../contexts/ThemeContext';
import { assetAllocation } from '../../data/mockData';

const AssetAllocation = () => {
  const { theme, currentTheme } = useTheme();
  
  // Function to get text color based on theme
  const getTitleColor = () => {
    if (currentTheme === 'cyberpunk') {
      return '#05D9E8'; // Neon blue for cyberpunk theme
    } else if (currentTheme === 'light') {
      return '#8B5CF6'; // Purple for light theme
    } else {
      return '#6366F1'; // Indigo for dark theme
    }
  };
  
  return (
    <FloatingCard theme={theme} intensity={0.3}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '1rem',
      }}>
        <h3 style={{ 
          fontSize: '1.1rem', 
          fontWeight: 'bold',
          color: getTitleColor()
        }}>
          Asset Allocation
        </h3>
      </div>
      
      <div style={{ height: '250px' }}>
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={assetAllocation}
              cx="50%"
              cy="50%"
              innerRadius={60}
              outerRadius={80}
              paddingAngle={2}
              dataKey="value"
            >
              {assetAllocation.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={entry.color} />
              ))}
            </Pie>
            <Tooltip 
              contentStyle={{ 
                background: theme.background.card.primary,
                border: `1px solid ${theme.border.primary}`,
                borderRadius: '0.5rem',
              }} 
              formatter={(value) => [`${value}%`, 'Allocation']}
            />
            <Legend />
          </PieChart>
        </ResponsiveContainer>
      </div>
      
      {/* Small summary stats below chart */}
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        marginTop: '1rem',
        padding: '0.75rem',
        borderRadius: '0.5rem',
        background: theme.background.tertiary,
      }}>
        <div>
          <div style={{ color: theme.text.tertiary, fontSize: '0.75rem', marginBottom: '0.25rem' }}>
            Total Assets
          </div>
          <div style={{ fontWeight: 'bold' }}>
            5
          </div>
        </div>
        
        <div>
          <div style={{ color: theme.text.tertiary, fontSize: '0.75rem', marginBottom: '0.25rem' }}>
            Largest Holding
          </div>
          <div style={{ fontWeight: 'bold' }}>
            ETH (35%)
          </div>
        </div>
        
        <div>
          <div style={{ color: theme.text.tertiary, fontSize: '0.75rem', marginBottom: '0.25rem' }}>
            Diversity Score
          </div>
          <div style={{ fontWeight: 'bold' }}>
            7.2/10
          </div>
        </div>
      </div>
    </FloatingCard>
  );
};

export default AssetAllocation;