import React from 'react';
import { ArrowUpRight, ArrowDownRight, RefreshCw } from 'lucide-react';
import FloatingCard from '../common/FloatingCard';
import { useTheme } from '../../contexts/ThemeContext';
import { recentTransactions } from '../../data/mockData';

const RecentTransactions = () => {
  const { theme, currentTheme } = useTheme();

  return (
    <FloatingCard theme={theme} intensity={0.3}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: '1rem',
      }}>
        <h3 style={{ 
          fontSize: '1.25rem', 
          fontWeight: 'bold',
          color: theme.primary, // Direct color instead of gradient with clipping
        }}>Transaction History</h3>
        
        <button style={{
          padding: '0.5rem 0.75rem',
          borderRadius: '0.5rem',
          fontSize: '0.875rem',
          fontWeight: 'medium',
          background: 'transparent',
          color: theme.primary,
          border: `1px solid ${theme.primary}`,
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: '0.25rem',
        }}>
          <span>View All</span>
          <ArrowUpRight size={14} />
        </button>
      </div>
      
      <div style={{ 
        display: 'grid', 
        gap: '0.75rem' 
      }}>
        {recentTransactions.map((tx, index) => (
          <div key={index} style={{
            padding: '1rem',
            borderRadius: '0.5rem',
            background: theme.background.card.secondary,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            border: `1px solid ${theme.border.primary}`,
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '1rem',
            }}>
              <div style={{
                padding: '0.75rem',
                borderRadius: '0.5rem',
                background: tx.type === 'Buy' ? `${theme.success}20` :
                            tx.type === 'Sell' ? `${theme.danger}20` :
                            `${theme.secondary}20`,
              }}>
                {tx.type === 'Buy' ? (
                  <ArrowUpRight size={20} color={theme.success} />
                ) : tx.type === 'Sell' ? (
                  <ArrowDownRight size={20} color={theme.danger} />
                ) : (
                  <RefreshCw size={20} color={theme.secondary} />
                )}
              </div>
              
              <div>
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem',
                }}>
                  <span style={{ fontWeight: 'medium' }}>
                    {tx.type} {tx.asset}
                  </span>
                  <span>{tx.chainIcon}</span>
                </div>
                <div style={{
                  color: theme.text.tertiary,
                  fontSize: '0.875rem',
                }}>
                  {tx.amount} • {tx.time}
                </div>
              </div>
            </div>
            
            <div style={{
              textAlign: 'right',
            }}>
              <div style={{ fontWeight: 'medium' }}>{tx.value}</div>
              <div style={{
                display: 'inline-block',
                padding: '0.25rem 0.5rem',
                borderRadius: '1rem',
                background: tx.status === 'Completed' ? `${theme.success}20` : `${theme.warning}20`,
                color: tx.status === 'Completed' ? theme.success : theme.warning,
                fontSize: '0.75rem',
                marginTop: '0.25rem',
              }}>
                {tx.status}
              </div>
            </div>
          </div>
        ))}
      </div>
    </FloatingCard>
  );
};

export default RecentTransactions;