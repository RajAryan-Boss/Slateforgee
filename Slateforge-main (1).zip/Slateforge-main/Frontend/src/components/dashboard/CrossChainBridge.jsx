import React, { useState } from 'react';
import { Link, Send, ChevronDown } from 'lucide-react';
import FloatingCard from '../common/FloatingCard';
import AnimatedButton from '../common/AnimatedButton';
import { useTheme } from '../../contexts/ThemeContext';

const CrossChainBridge = () => {
  const { theme, currentTheme } = useTheme();
  const [amount, setAmount] = useState('0.5');
  
  return (
    <FloatingCard theme={theme} intensity={0.5}>
      <div style={{
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'flex-start',
        marginBottom: '1.5rem',
      }}>
        <div>
          <h3 style={{ 
            fontSize: '1.25rem', 
            fontWeight: 'bold',
            color: currentTheme === 'cyberpunk' ? theme.secondary : theme.accent,
            marginBottom: '0.5rem',
          }}>Cross-Chain Transfer</h3>
          <p style={{
            color: theme.text.secondary,
            fontSize: '0.875rem',
          }}>Transfer assets seamlessly between blockchains with minimal fees</p>
        </div>
        
        <div style={{
          padding: '0.75rem',
          borderRadius: '0.5rem',
          background: currentTheme === 'cyberpunk' ? `${theme.secondary}20` : `${theme.accent}20`,
        }}>
          <Link size={20} color={currentTheme === 'cyberpunk' ? theme.secondary : theme.accent} />
        </div>
      </div>
      
      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: '1rem',
        marginBottom: '1.5rem',
      }}>
        <div>
          <label style={{
            display: 'block',
            fontSize: '0.875rem',
            color: theme.text.tertiary,
            marginBottom: '0.5rem',
          }}>From</label>
          <div style={{
            padding: '0.75rem',
            borderRadius: '0.5rem',
            background: theme.background.card.secondary,
            border: `1px solid ${theme.border.primary}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: 'pointer',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
            }}>
              <div style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                background: '#627EEA',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '0.75rem',
              }}>Ξ</div>
              <span>Ethereum</span>
            </div>
            <ChevronDown size={16} color={theme.text.tertiary} />
          </div>
        </div>
        
        <div>
          <label style={{
            display: 'block',
            fontSize: '0.875rem',
            color: theme.text.tertiary,
            marginBottom: '0.5rem',
          }}>To</label>
          <div style={{
            padding: '0.75rem',
            borderRadius: '0.5rem',
            background: theme.background.card.secondary,
            border: `1px solid ${theme.border.primary}`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            cursor: 'pointer',
          }}>
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.5rem',
            }}>
              <div style={{
                width: '24px',
                height: '24px',
                borderRadius: '50%',
                background: '#8247E5',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
                fontSize: '0.75rem',
              }}>P</div>
              <span>Polygon</span>
            </div>
            <ChevronDown size={16} color={theme.text.tertiary} />
          </div>
        </div>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          fontSize: '0.875rem',
          color: theme.text.tertiary,
          marginBottom: '0.5rem',
        }}>Asset</label>
        <div style={{
          padding: '0.75rem',
          borderRadius: '0.5rem',
          background: theme.background.card.secondary,
          border: `1px solid ${theme.border.primary}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          cursor: 'pointer',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.5rem',
          }}>
            <div style={{
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              background: '#627EEA',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              color: 'white',
              fontSize: '0.75rem',
            }}>Ξ</div>
            <span>Ethereum (ETH)</span>
          </div>
          <ChevronDown size={16} color={theme.text.tertiary} />
        </div>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          fontSize: '0.875rem',
          color: theme.text.tertiary,
          marginBottom: '0.5rem',
        }}>Amount</label>
        <div style={{
          padding: '0.75rem',
          borderRadius: '0.5rem',
          background: theme.background.card.secondary,
          border: `1px solid ${theme.border.primary}`,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <input 
            type="text" 
            placeholder="0.0" 
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              fontSize: '1rem',
              width: '100%',
            }}
          />
          <button style={{
            padding: '0.25rem 0.5rem',
            borderRadius: '0.25rem',
            background: theme.background.tertiary,
            color: theme.text.primary,
            border: 'none',
            fontSize: '0.75rem',
            cursor: 'pointer',
          }}>MAX</button>
        </div>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          fontSize: '0.75rem',
          color: theme.text.tertiary,
          marginTop: '0.5rem',
        }}>
          <span>Available: 2.45 ETH</span>
          <span>≈ $1,622.84</span>
        </div>
      </div>
      
      <AnimatedButton theme={theme} fullWidth={true}>
        <Send size={18} />
        <span>Bridge Assets</span>
      </AnimatedButton>
    </FloatingCard>
  );
};

export default CrossChainBridge;