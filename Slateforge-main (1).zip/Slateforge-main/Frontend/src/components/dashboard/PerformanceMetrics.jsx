import React from 'react';
import { ArrowUpRight, ArrowDownRight } from 'lucide-react';
import FloatingCard from '../common/FloatingCard';
import { useTheme } from '../../contexts/ThemeContext';
import { performanceMetrics } from '../../data/mockData';

const PerformanceMetrics = () => {
  const { theme } = useTheme();

  return (
    <div style={{
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
      gap: '1rem',
      marginBottom: '1.5rem',
    }}>
      {performanceMetrics.map((metric, index) => (
        <FloatingCard key={index} theme={theme} intensity={0.5}>
          <div style={{
            display: 'flex',
            alignItems: 'flex-start',
            justifyContent: 'space-between',
            marginBottom: '0.75rem',
          }}>
            <p style={{
              color: theme.text.tertiary,
              fontSize: '0.875rem',
            }}>{metric.metric}</p>
            
            <div style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.25rem',
              padding: '0.25rem 0.5rem',
              borderRadius: '1rem',
              background: metric.trend === 'up' ? `${theme.success}20` : `${theme.danger}20`,
              color: metric.trend === 'up' ? theme.success : theme.danger,
              fontSize: '0.75rem',
            }}>
              {metric.trend === 'up' ? (
                <ArrowUpRight size={14} />
              ) : (
                <ArrowDownRight size={14} />
              )}
              <span>{metric.change}</span>
            </div>
          </div>
          
          <h3 style={{
            fontSize: '1.5rem',
            fontWeight: 'bold',
          }}>{metric.value}</h3>
        </FloatingCard>
      ))}
    </div>
  );
};

export default PerformanceMetrics;