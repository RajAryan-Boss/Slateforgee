import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, UserPlus } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';

const RegisterForm = ({ onSuccess, switchToLogin }) => {
  const { theme } = useTheme();
  const { register } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeToTerms, setAgreeToTerms] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password || !confirmPassword) {
      setError('Please fill in all fields');
      return;
    }
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }
    
    if (!agreeToTerms) {
      setError('You must agree to the Terms of Service');
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const success = register(email, password);
      
      if (success) {
        if (onSuccess) {
          onSuccess();
        }
      } else {
        setError('Registration failed. Please try again.');
      }
      
      setIsLoading(false);
    }, 800);
  };
  
  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div style={{
          padding: '0.75rem',
          borderRadius: '0.5rem',
          background: `${theme.danger}15`,
          color: theme.danger,
          marginBottom: '1.5rem',
          fontSize: '0.875rem',
        }}>
          {error}
        </div>
      )}
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          marginBottom: '0.5rem',
          color: theme.text.secondary,
          fontSize: '0.9rem',
        }}>
          Email
        </label>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '0.75rem 1rem',
          borderRadius: '0.5rem',
          border: `1px solid ${theme.border.primary}`,
          background: theme.background.secondary,
        }}>
          <Mail size={18} color={theme.text.tertiary} style={{ marginRight: '0.75rem' }} />
          <input
            type="email"
            placeholder="your@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              width: '100%',
              fontSize: '1rem',
            }}
          />
        </div>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          marginBottom: '0.5rem',
          color: theme.text.secondary,
          fontSize: '0.9rem',
        }}>
          Password
        </label>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '0.75rem 1rem',
          borderRadius: '0.5rem',
          border: `1px solid ${theme.border.primary}`,
          background: theme.background.secondary,
        }}>
          <Lock size={18} color={theme.text.tertiary} style={{ marginRight: '0.75rem' }} />
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Create a strong password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              width: '100%',
              fontSize: '1rem',
            }}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            style={{
              background: 'transparent',
              border: 'none',
              padding: '0',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {showPassword ? 
              <EyeOff size={18} color={theme.text.tertiary} /> : 
              <Eye size={18} color={theme.text.tertiary} />
            }
          </button>
        </div>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          marginBottom: '0.5rem',
          color: theme.text.secondary,
          fontSize: '0.9rem',
        }}>
          Confirm Password
        </label>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '0.75rem 1rem',
          borderRadius: '0.5rem',
          border: `1px solid ${theme.border.primary}`,
          background: theme.background.secondary,
        }}>
          <Lock size={18} color={theme.text.tertiary} style={{ marginRight: '0.75rem' }} />
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Confirm your password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              width: '100%',
              fontSize: '1rem',
            }}
          />
        </div>
      </div>
      
      <div style={{ marginBottom: '2rem' }}>
        <div style={{
          display: 'flex',
          alignItems: 'flex-start',
          gap: '0.5rem',
        }}>
          <input
            type="checkbox"
            id="terms"
            checked={agreeToTerms}
            onChange={(e) => setAgreeToTerms(e.target.checked)}
            style={{
              width: '16px',
              height: '16px',
              accentColor: theme.secondary,
              marginTop: '0.25rem',
            }}
          />
          <label
            htmlFor="terms"
            style={{
              color: theme.text.secondary,
              fontSize: '0.9rem',
              lineHeight: '1.5',
            }}
          >
            I agree to the <a style={{ color: theme.secondary, cursor: 'pointer' }}>Terms of Service</a> and <a style={{ color: theme.secondary, cursor: 'pointer' }}>Privacy Policy</a>
          </label>
        </div>
      </div>
      
      <button
        type="submit"
        disabled={isLoading}
        style={{
          width: '100%',
          padding: '0.9rem',
          borderRadius: '0.5rem',
          background: theme.gradient.secondary,
          color: 'white',
          fontWeight: 'bold',
          fontSize: '1rem',
          border: 'none',
          cursor: isLoading ? 'not-allowed' : 'pointer',
          boxShadow: `0 0 20px ${theme.secondary}30`,
          transition: 'all 0.3s ease',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          marginBottom: '1.5rem',
          opacity: isLoading ? 0.7 : 1,
        }}
      >
        <UserPlus size={18} />
        <span>{isLoading ? 'Creating Account...' : 'Create Account'}</span>
      </button>
      
      <div style={{
        textAlign: 'center',
        color: theme.text.secondary,
        fontSize: '0.9rem',
      }}>
        Already have an account?{' '}
        <a
          onClick={switchToLogin}
          style={{
            color: theme.secondary,
            cursor: 'pointer',
            fontWeight: 'medium',
          }}
        >
          Sign in
        </a>
      </div>
    </form>
  );
};

export default RegisterForm;