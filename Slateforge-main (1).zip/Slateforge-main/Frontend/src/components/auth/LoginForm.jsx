import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, LogIn } from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';

const LoginForm = ({ onSuccess, switchToRegister }) => {
  const { theme, currentTheme } = useTheme();
  const { login } = useAuth();
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  
  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    if (!email || !password) {
      setError('Please fill in all fields');
      return;
    }
    
    setIsLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      const success = login(email, password);
      
      if (success) {
        if (onSuccess) {
          onSuccess();
        }
      } else {
        setError('Invalid credentials. Please try again.');
      }
      
      setIsLoading(false);
    }, 800);
  };
  
  return (
    <form onSubmit={handleSubmit}>
      {error && (
        <div style={{
          padding: '0.75rem',
          borderRadius: '0.5rem',
          background: `${theme.danger}15`,
          color: theme.danger,
          marginBottom: '1.5rem',
          fontSize: '0.875rem',
        }}>
          {error}
        </div>
      )}
      
      <div style={{ marginBottom: '1.5rem' }}>
        <label style={{
          display: 'block',
          marginBottom: '0.5rem',
          color: theme.text.secondary,
          fontSize: '0.9rem',
        }}>
          Email
        </label>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '0.75rem 1rem',
          borderRadius: '0.5rem',
          border: `1px solid ${theme.border.primary}`,
          background: theme.background.secondary,
        }}>
          <Mail size={18} color={theme.text.tertiary} style={{ marginRight: '0.75rem' }} />
          <input
            type="email"
            placeholder="your@email.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              width: '100%',
              fontSize: '1rem',
            }}
          />
        </div>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <div style={{
          display: 'flex',
          justifyContent: 'space-between',
          marginBottom: '0.5rem',
        }}>
          <label style={{
            color: theme.text.secondary,
            fontSize: '0.9rem',
          }}>
            Password
          </label>
          <a style={{
            color: theme.primary,
            fontSize: '0.9rem',
            cursor: 'pointer',
          }}>
            Forgot password?
          </a>
        </div>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          padding: '0.75rem 1rem',
          borderRadius: '0.5rem',
          border: `1px solid ${theme.border.primary}`,
          background: theme.background.secondary,
        }}>
          <Lock size={18} color={theme.text.tertiary} style={{ marginRight: '0.75rem' }} />
          <input
            type={showPassword ? 'text' : 'password'}
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            style={{
              background: 'transparent',
              border: 'none',
              outline: 'none',
              color: theme.text.primary,
              width: '100%',
              fontSize: '1rem',
            }}
          />
          <button
            type="button"
            onClick={() => setShowPassword(!showPassword)}
            style={{
              background: 'transparent',
              border: 'none',
              padding: '0',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            {showPassword ? 
              <EyeOff size={18} color={theme.text.tertiary} /> : 
              <Eye size={18} color={theme.text.tertiary} />
            }
          </button>
        </div>
      </div>
      
      <div style={{ marginBottom: '2rem' }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
        }}>
          <input
            type="checkbox"
            id="remember"
            style={{
              width: '16px',
              height: '16px',
              accentColor: theme.primary,
            }}
          />
          <label
            htmlFor="remember"
            style={{
              color: theme.text.secondary,
              fontSize: '0.9rem',
            }}
          >
            Remember me for 30 days
          </label>
        </div>
      </div>
      
      <button
        type="submit"
        disabled={isLoading}
        style={{
          width: '100%',
          padding: '0.9rem',
          borderRadius: '0.5rem',
          background: theme.gradient.primary,
          color: currentTheme === 'dark' ? '#0F172A' : 'white',
          fontWeight: 'bold',
          fontSize: '1rem',
          border: 'none',
          cursor: isLoading ? 'not-allowed' : 'pointer',
          boxShadow: `0 0 20px ${theme.primary}30`,
          transition: 'all 0.3s ease',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '0.5rem',
          marginBottom: '1.5rem',
          opacity: isLoading ? 0.7 : 1,
        }}
      >
        <LogIn size={18} />
        <span>{isLoading ? 'Signing in...' : 'Sign in to Account'}</span>
      </button>
      
      <div style={{
        textAlign: 'center',
        color: theme.text.secondary,
        fontSize: '0.9rem',
      }}>
        Don't have an account?{' '}
        <a
          onClick={switchToRegister}
          style={{
            color: theme.primary,
            cursor: 'pointer',
            fontWeight: 'medium',
          }}
        >
          Sign up
        </a>
      </div>
    </form>
  );
};

export default LoginForm;