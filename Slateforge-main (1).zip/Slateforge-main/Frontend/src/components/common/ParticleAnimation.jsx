import React, { useRef, useEffect } from 'react';
import * as THREE from 'three';

const ParticleAnimation = ({ theme, opacity = 0.6 }) => {
  const containerRef = useRef(null);
  
  useEffect(() => {
    if (!containerRef.current) return;
    
    // Setup
    const container = containerRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight;
    
    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true });
    renderer.setSize(width, height);
    renderer.setClearColor(0x000000, 0);
    
    // Clear container first
    while (container.firstChild) {
      container.removeChild(container.firstChild);
    }
    container.appendChild(renderer.domElement);
    
    // Create particles
    const particlesCount = 150;
    const particles = new THREE.Group();
    
    // Parse the primary color to get RGB values
    let primaryColor;
    if (theme.primary.startsWith('#')) {
      const hex = theme.primary.replace('#', '');
      const r = parseInt(hex.substring(0, 2), 16) / 255;
      const g = parseInt(hex.substring(2, 4), 16) / 255;
      const b = parseInt(hex.substring(4, 6), 16) / 255;
      primaryColor = new THREE.Color(r, g, b);
    } else {
      primaryColor = new THREE.Color(theme.primary);
    }
    
    for (let i = 0; i < particlesCount; i++) {
      const geometry = new THREE.SphereGeometry(Math.random() * 0.2 + 0.1, 8, 8);
      const material = new THREE.MeshBasicMaterial({ 
        color: primaryColor,
        transparent: true,
        opacity: Math.random() * 0.5 + 0.2
      });
      
      const particle = new THREE.Mesh(geometry, material);
      
      // Position particles within a sphere
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);
      const radius = Math.random() * 10 + 5;
      
      particle.position.x = radius * Math.sin(phi) * Math.cos(theta);
      particle.position.y = radius * Math.sin(phi) * Math.sin(theta);
      particle.position.z = radius * Math.cos(phi);
      
      // Set random velocity
      particle.userData = {
        velocity: new THREE.Vector3(
          (Math.random() - 0.5) * 0.05,
          (Math.random() - 0.5) * 0.05,
          (Math.random() - 0.5) * 0.05
        ),
        initialX: particle.position.x,
        initialY: particle.position.y,
        initialZ: particle.position.z,
        phase: Math.random() * Math.PI * 2
      };
      
      particles.add(particle);
    }
    
    scene.add(particles);
    camera.position.z = 20;
    
    // Animation
    let frameId;
    const animate = () => {
      frameId = requestAnimationFrame(animate);
      
      // Move particles
      const time = Date.now() * 0.001; // time in seconds
      particles.children.forEach(particle => {
        const { initialX, initialY, initialZ, phase } = particle.userData;
        
        // Oscillating movement
        particle.position.x = initialX + Math.sin(time + phase) * 1.5;
        particle.position.y = initialY + Math.cos(time + phase) * 1.5;
        particle.position.z = initialZ + Math.sin(time * 0.5 + phase) * 1.5;
        
        // Slow rotation of entire particle system
        particles.rotation.y += 0.0003;
        particles.rotation.x += 0.0001;
      });
      
      renderer.render(scene, camera);
    };
    
    animate();
    
    // Handle resize
    const handleResize = () => {
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };
    
    window.addEventListener('resize', handleResize);
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(frameId);
      renderer.dispose();
    };
  }, [theme]);
  
  return (
    <div 
      ref={containerRef} 
      style={{ 
        position: 'absolute',
        width: '100%',
        height: '100%',
        zIndex: 0,
        opacity: opacity,
        pointerEvents: 'none'
      }}
    />
  );
};

export default ParticleAnimation;