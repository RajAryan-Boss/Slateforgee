import React, { useState } from 'react';
import { 
  Wallet, 
  BarChart3, 
  Settings, 
  Layers, 
  Zap, 
  Activity, 
  User, 
  Server, 
  Hexagon, 
  Moon, 
  Sun,
  Menu,
  LogOut,
  ChevronLeft
} from 'lucide-react';
import { useTheme } from '../../contexts/ThemeContext';
import { useAuth } from '../../contexts/AuthContext';
import { useWallet } from '../../contexts/WalletContext';

const Sidebar = ({ currentPage, setCurrentPage, walletAddress, onSidebarToggle }) => {
  const { theme, currentTheme, cycleTheme, setTheme } = useTheme();
  const { user, logout } = useAuth();
  const { disconnectWallet } = useWallet();
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Navigation items
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: <BarChart3 size={20} /> },
    { id: 'portfolio', label: 'Portfolio', icon: <Wallet size={20} /> },
    { id: 'strategies', label: 'Strategies', icon: <Zap size={20} /> },
    { id: 'multichain', label: 'Multi-Chain', icon: <Layers size={20} /> },
    { id: 'activity', label: 'Activity', icon: <Activity size={20} /> },
    { id: 'defi', label: 'DeFi Markets', icon: <Server size={20} /> },
    { id: 'settings', label: 'Settings', icon: <Settings size={20} /> },
  ];
  
  // Set background color based on theme
  const getSidebarBackground = () => {
    if (currentTheme === 'light') {
      return '#f1f5f9'; // Lighter background for light theme
    } else {
      return '#0A0E17'; // Dark background for other themes
    }
  };
  
  // Set text color for non-active items based on theme
  const getTextColor = () => {
    if (currentTheme === 'light') {
      return '#1E293B'; // Darker text for light theme
    } else {
      return 'rgba(255, 255, 255, 0.9)'; // Higher contrast for dark themes
    }
  };

  // Get a readable text color for theme options
  const getThemeOptionTextColor = () => {
    if (currentTheme === 'light') {
      return '#1E293B'; // Dark text for light theme
    } else {
      return 'white'; // White text for dark themes
    }
  };

  // Toggle sidebar function
  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
    if (onSidebarToggle) {
      onSidebarToggle(!isCollapsed);
    }
  };

  // Handle sign out
  const handleSignOut = () => {
    disconnectWallet();
    if (logout) {
      logout();
    }
  };
  
  return (
    <>
      {/* Hamburger menu for mobile/collapsed state */}
      {isCollapsed && (
        <div 
          onClick={toggleSidebar}
          style={{
            position: 'fixed',
            top: '1rem',
            left: '1rem',
            zIndex: 1000,
            background: theme.gradient.primary,
            borderRadius: '0.5rem',
            padding: '0.5rem',
            cursor: 'pointer',
            boxShadow: `0 0 15px ${theme.primary}50`,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Menu size={24} color={currentTheme === 'dark' ? '#0F172A' : 'white'} />
        </div>
      )}

      {/* Sidebar */}
      <div style={{
        width: isCollapsed ? '0' : '240px',
        background: getSidebarBackground(),
        backdropFilter: 'blur(10px)',
        borderRight: isCollapsed ? 'none' : `1px solid ${theme.border.primary}`,
        height: '100%',
        padding: isCollapsed ? '0' : '1.5rem 1rem',
        display: 'flex',
        flexDirection: 'column',
        transition: 'all 0.3s ease',
        position: 'relative',
        overflow: 'hidden',
        zIndex: 50,
      }}>
        {/* Close sidebar button (visible when sidebar is open) */}
        {!isCollapsed && (
          <div 
            onClick={toggleSidebar}
            style={{
              position: 'absolute',
              top: '1rem',
              right: '1rem',
              cursor: 'pointer',
              color: getTextColor(),
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              padding: '0.25rem',
              borderRadius: '0.25rem',
              background: 'rgba(0, 0, 0, 0.1)',
              zIndex: 10,
            }}
          >
            <ChevronLeft size={18} />
          </div>
        )}

        {/* Logo */}
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          marginBottom: '2rem',
        }}>
          <div style={{
            width: '40px',
            height: '40px',
            borderRadius: '8px',
            background: theme.gradient.primary,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            boxShadow: `0 0 20px ${theme.primary}50`,
            overflow: 'hidden', // For logo image
          }}>
            {/* Logo image or fallback icon */}
            <img 
              src="/assets/images/logo.png"
              alt="SlateForge"
              style={{ width: '100%', height: '100%', objectFit: 'cover' }}
              onError={(e) => {
                e.target.style.display = 'none';
                e.target.nextSibling.style.display = 'block';
              }}
            />
            <Hexagon 
              size={24} 
              color={currentTheme === 'dark' ? '#0F172A' : 'white'} 
              style={{ display: 'none' }} // Hidden by default, shown if image fails
            />
          </div>
          <span style={{
            fontSize: '1.25rem',
            fontWeight: 'bold',
            color: getTextColor(),
            marginRight: '1rem',
          }}>
            SlateForge
          </span>
        </div>
        
        {/* Navigation */}
        <nav style={{
          display: 'flex',
          flexDirection: 'column',
          gap: '0.5rem',
        }}>
          {navItems.map((item) => (
            <div 
              key={item.id}
              onClick={() => setCurrentPage(item.id)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.75rem',
                padding: '0.75rem 1rem',
                borderRadius: '0.5rem',
                background: currentPage === item.id ? theme.gradient.primary : 'transparent',
                color: currentPage === item.id 
                  ? (currentTheme === 'dark' ? '#0F172A' : 'white') 
                  : getTextColor(),
                cursor: 'pointer',
                boxShadow: currentPage === item.id ? `0 0 15px ${theme.primary}60` : 'none',
                transition: 'all 0.2s',
              }}
            >
              {item.icon}
              <span>{item.label}</span>
            </div>
          ))}
        </nav>
        
        {/* Theme selector */}
        <div style={{
          marginTop: 'auto',
          padding: '0.75rem 1rem',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: '0.5rem',
          }}>
            <span style={{ color: getTextColor() }}>UI Theme</span>
            <button 
              onClick={cycleTheme}
              style={{ 
                cursor: 'pointer',
                padding: '0.25rem', 
                borderRadius: '0.25rem',
                background: 'rgba(0, 0, 0, 0.1)',
                border: 'none',
                color: getTextColor(),
                display: 'flex',
                alignItems: 'center',
              }}
            >
              {currentTheme === 'dark' ? (
                <Zap size={16} />
              ) : currentTheme === 'cyberpunk' ? (
                <Sun size={16} />
              ) : (
                <Moon size={16} />
              )}
            </button>
          </div>
          
          <div style={{
            display: 'flex',
            flexDirection: 'column',
            gap: '0.5rem',
            padding: '0.5rem',
            borderRadius: '0.5rem',
            background: 'rgba(0, 0, 0, 0.1)',
            marginTop: '0.5rem',
          }}>
            <div 
              onClick={() => setTheme('dark')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.5rem',
                borderRadius: '0.25rem',
                cursor: 'pointer',
                background: currentTheme === 'dark' ? 'rgba(0, 0, 0, 0.15)' : 'transparent',
              }}
            >
              <div style={{
                width: '16px',
                height: '16px',
                borderRadius: '50%',
                background: '#10B981',
                border: currentTheme === 'dark' ? '2px solid white' : '2px solid transparent',
              }}></div>
              <span style={{
                color: getThemeOptionTextColor(),
                fontWeight: currentTheme === 'dark' ? 'bold' : 'normal'
              }}>Dark Emerald</span>
            </div>
            
            <div 
              onClick={() => setTheme('cyberpunk')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.5rem',
                borderRadius: '0.25rem',
                cursor: 'pointer',
                background: currentTheme === 'cyberpunk' ? 'rgba(0, 0, 0, 0.15)' : 'transparent',
              }}
            >
              <div style={{
                width: '16px',
                height: '16px',
                borderRadius: '50%',
                background: '#FF2A6D',
                border: currentTheme === 'cyberpunk' ? '2px solid white' : '2px solid transparent',
              }}></div>
              <span style={{
                color: getThemeOptionTextColor(),
                fontWeight: currentTheme === 'cyberpunk' ? 'bold' : 'normal'
              }}>Neon</span>
            </div>
            
            <div 
              onClick={() => setTheme('light')}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.5rem',
                borderRadius: '0.25rem',
                cursor: 'pointer',
                background: currentTheme === 'light' ? 'rgba(0, 0, 0, 0.15)' : 'transparent',
              }}
            >
              <div style={{
                width: '16px',
                height: '16px',
                borderRadius: '50%',
                background: '#0EA5E9',
                border: currentTheme === 'light' ? '2px solid #0F172A' : '2px solid transparent',
              }}></div>
              <span style={{
                color: getThemeOptionTextColor(),
                fontWeight: currentTheme === 'light' ? 'bold' : 'normal'
              }}>Light</span>
            </div>
          </div>
        </div>
        
        {/* User profile and sign out */}
        <div style={{
          marginTop: '1rem',
        }}>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            gap: '0.75rem',
            padding: '0.75rem 1rem',
            borderRadius: '0.5rem',
            background: 'rgba(0, 0, 0, 0.1)',
            marginBottom: '0.5rem',
          }}>
            <div style={{
              width: '36px',
              height: '36px',
              borderRadius: '50%',
              background: theme.gradient.accent,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <User size={18} color='white' />
            </div>
            <div style={{
              display: 'flex',
              flexDirection: 'column',
            }}>
              <span style={{ 
                fontWeight: 'medium',
                color: getTextColor(), 
              }}>
                {user ? user.name : 'Guest'}
              </span>
              <span style={{ 
                fontSize: '0.75rem', 
                color: getTextColor(),
                opacity: 0.7
              }}>
                {walletAddress || (user ? user.walletAddress : '')}
              </span>
            </div>
          </div>
          
          {/* Sign out button */}
          <div 
            onClick={handleSignOut}
            style={{
              display: 'flex',
              alignItems: 'center',
              gap: '0.75rem',
              padding: '0.75rem 1rem',
              borderRadius: '0.5rem',
              background: 'transparent',
              border: `1px solid ${theme.border.primary}`,
              color: getTextColor(),
              cursor: 'pointer',
              transition: 'all 0.2s',
            }}
          >
            <LogOut size={18} />
            <span>Sign Out</span>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;