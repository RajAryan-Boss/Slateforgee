import React, { useRef, useEffect } from 'react';

const FloatingCard = ({ children, theme, intensity = 1, className = '' }) => {
  const cardRef = useRef(null);
  
  useEffect(() => {
    const card = cardRef.current;
    if (!card) return;
    
    const handleMouseMove = (e) => {
      const rect = card.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      
      const centerX = rect.width / 2;
      const centerY = rect.height / 2;
      
      const percentX = (x - centerX) / centerX;
      const percentY = (y - centerY) / centerY;
      
      const maxRotation = 5 * intensity;
      const rotateX = -percentY * maxRotation;
      const rotateY = percentX * maxRotation;
      
      card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg)`;
      
      // Highlight effect
      const gradientX = 50 + percentX * 15;
      const gradientY = 50 + percentY * 15;
      card.style.background = `radial-gradient(circle at ${gradientX}% ${gradientY}%, ${theme.background.card.highlight}, ${theme.background.card.primary})`;
    };
    
    const handleMouseLeave = () => {
      card.style.transform = 'perspective(1000px) rotateX(0) rotateY(0)';
      card.style.background = theme.background.card.primary;
    };
    
    card.addEventListener('mousemove', handleMouseMove);
    card.addEventListener('mouseleave', handleMouseLeave);
    
    return () => {
      card.removeEventListener('mousemove', handleMouseMove);
      card.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, [theme, intensity]);
  
  return (
    <div 
      ref={cardRef} 
      className={className}
      style={{
        background: theme.background.card.primary,
        borderRadius: '0.75rem',
        padding: '1.25rem',
        backdropFilter: 'blur(10px)',
        border: `1px solid ${theme.border.primary}`,
        boxShadow: '0 10px 25px rgba(0, 0, 0, 0.1)',
        transition: 'transform 0.1s ease-out, box-shadow 0.1s ease-out, background 0.3s ease-out',
        transformStyle: 'preserve-3d',
      }}
    >
      {children}
    </div>
  );
};

export default FloatingCard;