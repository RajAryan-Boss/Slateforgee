import React from 'react';

const AnimatedButton = ({ 
  children, 
  theme, 
  primary = true, 
  onClick,
  className = '',
  fullWidth = false,
  size = 'medium' // 'small', 'medium', 'large'
}) => {
  // Determine padding based on size
  const getPadding = () => {
    switch (size) {
      case 'small':
        return '0.5rem 0.75rem';
      case 'large':
        return '1rem 1.5rem';
      case 'medium':
      default:
        return '0.75rem 1.25rem';
    }
  };
  
  // Determine font size based on size
  const getFontSize = () => {
    switch (size) {
      case 'small':
        return '0.875rem';
      case 'large':
        return '1.125rem';
      case 'medium':
      default:
        return '1rem';
    }
  };
  
  return (
    <button
      onClick={onClick}
      className={className}
      style={{
        padding: getPadding(),
        borderRadius: '0.5rem',
        background: primary ? theme.gradient.primary : 'transparent',
        border: primary ? 'none' : `1px solid ${theme.primary}`,
        color: primary ? (theme.id === 'dark' ? '#0F172A' : 'white') : theme.primary,
        fontWeight: 'medium',
        cursor: 'pointer',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '0.5rem',
        boxShadow: primary ? `0 0 15px ${theme.primary}40` : 'none',
        transition: 'all 0.3s ease',
        position: 'relative',
        overflow: 'hidden',
        width: fullWidth ? '100%' : 'auto',
        fontSize: getFontSize(),
      }}
    >
      <div
        style={{
          position: 'absolute',
          top: '0',
          left: '-100%',
          width: '100%',
          height: '100%',
          background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent)',
          animation: 'shine 1.5s infinite',
          pointerEvents: 'none',
        }}
      />
      {children}
      <style jsx>{`
        @keyframes shine {
          0% {
            left: -100%;
          }
          50%, 100% {
            left: 100%;
          }
        }
        button:hover {
          transform: translateY(-2px);
          box-shadow: ${primary ? `0 8px 20px ${theme.primary}60` : `0 5px 15px rgba(0,0,0,0.1)`};
        }
        button:active {
          transform: translateY(0);
        }
      `}</style>
    </button>
  );
};

export default AnimatedButton;